__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/67fe5c1b79a2c727.js",
  "static/chunks/turbopack-c08d13d58eb10de6.js"
])
