__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/67fe5c1b79a2c727.js",
  "static/chunks/turbopack-2500b4626b15ae0f.js"
])
