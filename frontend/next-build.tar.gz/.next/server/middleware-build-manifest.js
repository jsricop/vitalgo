globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/67fe5c1b79a2c727.js",
      "static/chunks/turbopack-2500b4626b15ae0f.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/67fe5c1b79a2c727.js",
      "static/chunks/turbopack-c08d13d58eb10de6.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c85a7d07e7b82c9a.js",
    "static/chunks/5564f493499345f1.js",
    "static/chunks/63dba52cde864d84.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-933205662f0a709e.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];